package org.javaboy.vhr.controller.emp;

import org.javaboy.vhr.model.EmpSalary;
import org.javaboy.vhr.model.Employeeremove;

import java.util.List;

public class EmpSalaryController {
    public List<EmpSalary> getAllEmployeeRemove() {


        return null;
    }
}
