package org.javaboy.vhr.mapper;

import org.apache.ibatis.annotations.Param;
import org.javaboy.vhr.model.AdjustSalary;
import org.javaboy.vhr.model.Employee;
import org.javaboy.vhr.model.Employeeremove;
import org.javaboy.vhr.model.Salary;

import java.util.Date;
import java.util.List;

public interface AdjustSalaryMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(AdjustSalary record);

    int insertSelective(AdjustSalary record);

    AdjustSalary selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(AdjustSalary record);

    int updateByPrimaryKey(AdjustSalary record);

    List<AdjustSalary> getAllAdjustSalaries();

    List<AdjustSalary> getAdjustSalaryByPage(@Param("page") Integer page, @Param("size") Integer size, @Param("empremove") AdjustSalary adjustSalary, @Param("beginDateScope") Date[] beginDateScope);

    Long getTotal(@Param("empremove") AdjustSalary adjustSalary,@Param("beginDateScope") Date[] beginDateScope);
}